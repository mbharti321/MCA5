# BTech_Quiz

**Check out Live Website:**  [BTech_Quiz](https://mbharti321.github.io/BTech_Quiz)



## Use these credential for login

```
{
    "users": [
        {
            "emailId": "mbharti321@gmail.com",
            "password": "12345678"
        },
        {
            "emailId": "mbharti@gmail.com",
            "password": "password"
        },
        {
            "emailId": "manish@gmail.com",
            "password": "password"
        },
        {
            "emailId": "joseph@gmail.com",
            "password": "293sfvdet"
        }
        ,
        {
            "emailId": "1947235",
            "password": "password"
        }
    ]
}
```